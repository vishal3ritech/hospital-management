package com.spring.mvcnew;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class WelcomeController {

	@RequestMapping(value="/home", method= RequestMethod.GET)
public String welcomePage(Model model) {
//	public String welcomePage() {
		System.out.println("home paging is going to load...");
	model.addAttribute("name", "Home Page");
		
		return "welcome";
	}
	
	/*@RequestMapping(value="/login", method= RequestMethod.POST)
	public String loginPage(HttpServletRequest request) {
		System.out.println("login paging is going to load...");
		String name = request.getParameter("name");
		System.out.println("name:"+name);
		
		return "welcome";
	}
	
	@RequestMapping(value="/main", method= RequestMethod.GET)
	public String mainPage(Model model) {
		System.out.println("main paging is going to load...");
		model.addAttribute("name", "Main Page");
		
		return "welcome";
	}
	
	@RequestMapping(value="/menu", method= RequestMethod.GET)
	public String menuPage(Model model) {
		model.addAttribute("name", "Menu Page");
		System.out.println("menu paging is going to load...");
		return "welcome";
	}
	
	@RequestMapping(value="/header", method= RequestMethod.GET)
	public String headerPage() {
		System.out.println("header paging is going to load...");
		return "welcome";
	}
	*/
}
